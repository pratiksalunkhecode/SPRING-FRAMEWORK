package com.in29minute.learnspringonce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnspringonceApplicationTests {

	@Test
	void contextLoads() {
	}

}
