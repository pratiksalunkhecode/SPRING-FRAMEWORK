package com.in29minute.learnspringonce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnspringonceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnspringonceApplication.class, args);
	}

}
